// Talks to the Mira app on this Mac (127.0.0.1 only). Pages never reach Mira directly; they ask this worker.
const MIRA = 'http://127.0.0.1:47823';

async function call(path, body) {
  const r = await fetch(MIRA + path, {
    method: body ? 'POST' : 'GET',
    headers: { 'content-type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  });
  return r.json();
}

// Lets Mira know the extension is here.
const hello = () => call('/hello').catch(() => {});
chrome.alarms.create('hello', { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener(hello);
chrome.runtime.onStartup.addListener(hello);
chrome.runtime.onInstalled.addListener(hello);

const allowed = new Set(['/pending', '/fill', '/applied']);
chrome.runtime.onMessage.addListener((msg, sender, send) => {
  if (!allowed.has(msg && msg.path)) return false;
  call(msg.path, msg.body).then(send).catch(() => send({ offline: true }));
  return true; // answers later
});
