// Mira fills job applications you started from Job Hunt in the Mira app.
// It only acts on a page Mira says is one of your applications, fills what it can from your CV and background,
// attaches your tailored CV, and highlights the Submit button. It never submits for you.
(() => {
  if (window.__miraLoaded) return;
  window.__miraLoaded = true;

  const ask = (path, body) => new Promise((resolve) => {
    try { chrome.runtime.sendMessage({ path, body }, (r) => resolve(chrome.runtime.lastError ? null : r)); }
    catch (e) { resolve(null); }
  });

  let job = null;      // { job, title, company, cv, cvName, cvType }
  let pill = null;
  let filling = false;
  let watchedSubmit = new WeakSet();

  // ---- Finding the form's fields ----

  const visible = (el) => {
    const r = el.getBoundingClientRect();
    const s = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none';
  };

  const clean = (t) => (t || '').replace(/\s+/g, ' ').trim().slice(0, 200);

  function labelFor(el) {
    if (el.id) {
      const l = document.querySelector(`label[for="${CSS.escape(el.id)}"]`);
      if (l) return clean(l.innerText);
    }
    const by = el.getAttribute('aria-labelledby');
    if (by) {
      const t = by.split(/\s+/).map((id) => document.getElementById(id)).filter(Boolean).map((n) => n.innerText).join(' ');
      if (clean(t)) return clean(t);
    }
    if (el.getAttribute('aria-label')) return clean(el.getAttribute('aria-label'));
    const wrap = el.closest('label');
    if (wrap) return clean(wrap.innerText);
    // Text just before the field, in its container.
    let box = el.parentElement;
    for (let i = 0; i < 3 && box; i++, box = box.parentElement) {
      const t = clean(box.innerText);
      if (t && t.length < 160) return t;
    }
    return clean(el.placeholder || el.name || el.id);
  }

  function collect() {
    const fields = [];
    const radios = {};
    let n = 0;
    const tag = (el) => { if (!el.dataset.mira) el.dataset.mira = 'f' + (n++) + '_' + Math.random().toString(36).slice(2, 6); return el.dataset.mira; };
    document.querySelectorAll('input, textarea, select').forEach((el) => {
      const type = (el.type || el.tagName).toLowerCase();
      if (['hidden', 'submit', 'button', 'reset', 'password', 'image', 'file', 'search'].includes(type)) return;
      if (el.disabled || el.readOnly || !visible(el)) return;
      if (type === 'radio') {
        const key = el.name || tag(el);
        const group = radios[key] || (radios[key] = { els: [], label: '' });
        group.els.push(el);
        if (!group.label) {
          const fs = el.closest('fieldset');
          const legend = fs && fs.querySelector('legend');
          group.label = clean(legend ? legend.innerText : (el.closest('[role=radiogroup]') || {}).innerText || el.name);
        }
        return;
      }
      if (el.value && type !== 'checkbox' && type !== 'select-one') return; // already filled; leave it
      const f = { id: tag(el), label: labelFor(el), type, required: el.required || el.getAttribute('aria-required') === 'true' };
      if (el.tagName === 'SELECT') f.options = [...el.options].map((o) => clean(o.text)).filter(Boolean);
      fields.push(f);
    });
    Object.values(radios).forEach((g) => {
      if (g.els.some((e) => e.checked)) return;
      const id = tag(g.els[0]);
      g.els.forEach((e) => { e.dataset.miraGroup = id; });
      fields.push({ id, label: g.label, type: 'radio', options: g.els.map((e) => labelFor(e)), required: g.els.some((e) => e.required) });
    });
    return fields;
  }

  // ---- Typing values in a way React and friends notice ----

  function setValue(el, value) {
    const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : el.tagName === 'SELECT' ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
    el.focus();
    setter.call(el, value);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.blur();
  }

  function apply(id, value) {
    const v = String(value);
    const group = document.querySelectorAll(`[data-mira-group="${id}"]`);
    if (group.length) {
      const pick = [...group].find((e) => labelFor(e).toLowerCase() === v.toLowerCase())
        || [...group].find((e) => labelFor(e).toLowerCase().includes(v.toLowerCase()));
      if (pick) { pick.click(); mark(pick, 'filled'); return true; }
      return false;
    }
    const el = document.querySelector(`[data-mira="${id}"]`);
    if (!el) return false;
    if (el.type === 'checkbox') {
      const want = /^(true|yes|1)$/i.test(v);
      if (el.checked !== want) el.click();
    } else if (el.tagName === 'SELECT') {
      const opt = [...el.options].find((o) => clean(o.text).toLowerCase() === v.toLowerCase())
        || [...el.options].find((o) => clean(o.text).toLowerCase().includes(v.toLowerCase()));
      if (!opt) return false;
      setValue(el, opt.value);
    } else {
      setValue(el, v);
    }
    mark(el, 'filled');
    return true;
  }

  function mark(el, kind) {
    el.classList.remove('mira-filled', 'mira-todo');
    el.classList.add(kind === 'filled' ? 'mira-filled' : 'mira-todo');
  }

  // ---- The CV ----

  function attachCV() {
    if (!job || !job.cv) return 0;
    const inputs = [...document.querySelectorAll('input[type=file]')];
    if (!inputs.length) return 0;
    const isCV = (el) => /resume|résumé|cv\b|curriculum/i.test(labelFor(el) + ' ' + el.name + ' ' + el.id + ' ' + (el.accept || ''));
    const targets = inputs.filter(isCV);
    const list = targets.length ? targets : (inputs.length === 1 ? inputs : []);
    let done = 0;
    for (const el of list) {
      if (el.files && el.files.length) continue;
      try {
        const bytes = Uint8Array.from(atob(job.cv), (c) => c.charCodeAt(0));
        const file = new File([bytes], job.cvName || 'CV.pdf', { type: job.cvType || 'application/pdf' });
        const dt = new DataTransfer();
        dt.items.add(file);
        el.files = dt.files;
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        mark(el.closest('label, div') || el, 'filled');
        done++;
      } catch (e) { /* the site may block it; the user attaches it */ }
    }
    return done;
  }

  // ---- Submit: highlighted, never clicked ----

  function findSubmit() {
    const cands = [...document.querySelectorAll('button, input[type=submit], [role=button]')].filter(visible);
    return cands.find((b) => /^(submit|submit application|send application|apply|apply now|review|finish)$/i.test(clean(b.innerText || b.value)))
      || cands.find((b) => b.type === 'submit')
      || cands.find((b) => /submit|send application/i.test(clean(b.innerText || b.value)));
  }

  function watchSubmit() {
    const b = findSubmit();
    if (!b) return;
    b.classList.add('mira-submit');
    if (watchedSubmit.has(b)) return;
    watchedSubmit.add(b);
    b.addEventListener('click', () => {
      // A form the browser won't send yet (a required field is empty) isn't an application.
      const form = b.form || b.closest('form');
      if (form && !form.checkValidity()) return;
      if (/submit|send|apply/i.test(clean(b.innerText || b.value)) && job) {
        ask('/applied', { job: job.job });
        say('Sent. Mira marked it as applied.', false);
      }
    }, true);
  }

  // ---- The little panel ----

  function say(text, withButton) {
    if (!pill) {
      pill = document.createElement('div');
      pill.className = 'mira-pill';
      document.documentElement.appendChild(pill);
    }
    pill.innerHTML = '';
    const dot = document.createElement('span'); dot.className = 'mira-dot';
    const t = document.createElement('span'); t.textContent = text;
    pill.append(dot, t);
    if (withButton) {
      const b = document.createElement('button');
      b.textContent = 'Fill this step';
      b.onclick = () => fill();
      pill.append(b);
    }
    const x = document.createElement('button');
    x.className = 'mira-x'; x.textContent = '×'; x.title = 'Hide';
    x.onclick = () => pill.remove();
    pill.append(x);
  }

  async function fill() {
    if (filling || !job) return;
    filling = true;
    say(`Filling your application to ${job.company}…`, false);
    const files = attachCV();
    const fields = collect();
    let filled = 0;
    if (fields.length) {
      const r = await ask('/fill', { job: job.job, fields });
      const values = (r && r.values) || [];
      for (const v of values) if (v && v.id != null && v.value != null && String(v.value) !== '' && apply(v.id, v.value)) filled++;
      // What's left and required: yours to answer.
      const done = new Set(values.map((v) => v.id));
      fields.filter((f) => f.required && !done.has(f.id)).forEach((f) => {
        const el = document.querySelector(`[data-mira="${f.id}"]`);
        if (el) mark(el, 'todo');
      });
    }
    watchSubmit();
    filling = false;
    const parts = [];
    if (filled) parts.push(`filled ${filled} field${filled === 1 ? '' : 's'}`);
    if (files) parts.push('attached your CV');
    say(parts.length ? `Mira ${parts.join(' and ')}. Check the yellow ones, then click Submit.` : 'Nothing to fill on this step.', true);
  }

  // ---- Is this one of your applications? ----

  function looksLikeForm() {
    return !!document.querySelector('input[type=file]') || document.querySelectorAll('input, textarea, select').length >= 4;
  }

  let asked = 0;
  async function check() {
    if (job || asked > 3) return;
    asked++;
    const r = await ask('/pending', { url: location.href, form: looksLikeForm() });
    if (r && r.job) {
      job = r;
      if (looksLikeForm()) fill();
      else say(`Mira is applying to ${job.title} at ${job.company}. Click Apply on the page, and Mira fills the form.`, true);
      // Multi-step forms (LinkedIn Easy Apply, Workday): offer to fill each new step.
      new MutationObserver(() => { if (pill && !filling) watchSubmit(); }).observe(document.body, { childList: true, subtree: true });
    }
  }

  check();
  setTimeout(check, 2500);
  // Single-page sites change pages without loading.
  let last = location.href;
  setInterval(() => { if (location.href !== last) { last = location.href; asked = 0; if (job) { say(`Next step for ${job.company}.`, true); } else check(); } }, 1500);
})();
